package example;

import class_06.GeometricObject;

public class TestGEo {

	public static void main(String[] args) {
		GeometricObject obj1 = new GeometricObject("red", true);
		System.out.println(obj1);
	}
}
