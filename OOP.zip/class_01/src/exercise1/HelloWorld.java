package exercise1;

public class HelloWorld {

	public static void main(String[] args) {
	    System.out.println("Hello world");
	    System.out.println("How are you?");
	    System.out.println("I'm fine");
	    System.out.println("thank you");

	}

}
